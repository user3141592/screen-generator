#!/usr/bin
#use screen-generator to create a screen with system monitoring utilities

COMMAND_CHAIN="iostat;lsof;Psacct;acct;htop"

